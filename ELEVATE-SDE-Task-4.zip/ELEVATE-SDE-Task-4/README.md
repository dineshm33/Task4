# ELEVATE-SDE-Task-4 — CredVault Full Stack

Frontend: React + Vite. Backend: Node.js + Express. Database: MongoDB.

## Run backend
1. `cd backend`
2. Copy `.env.example` to `.env`; configure MongoDB and a strong JWT secret.
3. `npm install`
4. `npm run dev`

Backend: `http://localhost:5000`.

## Run frontend in a second terminal
1. `cd frontend`
2. Copy `.env.example` to `.env` if you need to change the API URL.
3. `npm install`
4. `npm run dev`
5. Open the Vite URL.

Demo admin credentials: `admin` / `admin` (change in backend `.env` before deployment).

Citizen request → MongoDB application record → admin approval creates certificate → public verification → admin revocation. Revocation updates only the certificate status, not the application record.

## Submission evidence
Add screenshots of Home, Request, Track, Verify, Admin Login, Applications and Certificates, plus a short screen recording of the end-to-end flow.
