# CredVault Task 4 API
Independent backend copy for the Task 4 full-stack project. See root README for setup.
